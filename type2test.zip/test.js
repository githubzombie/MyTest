var oShell = new ActiveXObject("Shell.Application");
oShell.ShellExecute("C:\\Windows\\system32\\calc.exe","","","open","1");